package com.techm.ms.resource;

import java.util.List;

import javax.ws.rs.core.Link;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

import com.techm.ms.exception.CustomError;
import com.techm.ms.model.User;
import com.techm.ms.model.representation.ResourceCollection;
import com.techm.ms.service.UserService;
import com.techm.ms.service.UserServiceImpl;

@Controller
public class UserResourceImpl implements UserResource {


	public static final Logger logger = LoggerFactory.getLogger(UserResourceImpl.class);

	@Autowired
	UserService userService; //Service which will do all data retrieval/manipulation work

	private static String baseUrl = "/users";

	
	
	/**
	 * Find all the USERS from the Server
	 *
	 * 
	 */
	
	
	@Override
	public Response findAllUsers() {

		logger.info(" coming to UserResourceImpl!!!!!!!!!!!");

		List<User> users = userService.findAllUsers();		
		if (users == null) {
			return Response.noContent().build();
		}		
		Link link = Link.fromUri(baseUrl).rel("self").build();		
		ResourceCollection<User> resource = new ResourceCollection<>(users);
		return Response.ok(resource).links(link).build();
	}	


	/**
	 * Find a particular USer for the given User ID
	 * 
	 * @throws NOT_FOUND if no matching User found
	 * @throws FOUND, if an User is found
	 */

	public Response findUser(long userId) {
		
		logger.info( " ================ findUser ==============");
		
		
		UserService usObj = new UserServiceImpl();

		User user = usObj.findById(userId);

		// if user exists
		if(user != null ){
			logger.info( " Found User ********** ");
			return Response.status(Response.Status.FOUND).entity(user).build();

		}else {

			// if user doesn't exists
			String errorMessage = "An User with id " + userId +  " not found";

			String errorCode = Response.Status.NOT_FOUND.toString(); 		    
			CustomError custError = new CustomError(errorMessage, errorCode);

			return Response.status(Response.Status.NOT_FOUND).entity(custError).build();
		}
	}








	/**
	 * Create a new User 
	 * 
	 * @throws CONFLICT if User exists
	 * @throws CREATED, if User is successfully saved
	 */
	public Response createUser(@RequestBody User newUser) {

		logger.info( " Create New User !!!!!!!!!!!!!! ");
		UserService usObj = new UserServiceImpl();

		User user = usObj.findByName(newUser.getName());


		// if user doesn't exists
		if(user == null ){
			usObj.saveUser(newUser);
			logger.info( " Created User ********** ");
			return Response.status(Response.Status.CREATED).entity(newUser).build();

		}else {

			// if user exists
			String errorMessage = "Unable to Create. An User with name already exists";

			String errorCode = Response.Status.CONFLICT.toString(); 		    
			CustomError custError = new CustomError(errorMessage, errorCode);

			return Response.status(Response.Status.CONFLICT).entity(custError).build();
		}

	}

}
