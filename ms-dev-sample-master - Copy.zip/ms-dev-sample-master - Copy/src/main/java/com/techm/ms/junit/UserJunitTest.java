package com.techm.ms.junit;



import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.post;
import static org.hamcrest.CoreMatchers.equalTo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.restassured.specification.RequestSpecification;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.techm.ms.model.User;
import com.techm.ms.resource.UserResourceImpl;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class UserJunitTest {
	
	
	
	public static final Logger logger = LoggerFactory.getLogger(UserJunitTest.class);

	
	
	@BeforeClass
	public static void init() {
		RestAssured.baseURI = "http://localhost";
		RestAssured.port = 1234;
	}

	@Test
	public void testFetchUser() {
		
		get("http://localhost:1234/api/users/1")
		.then()
		.body("id", equalTo(1))
		.body("name", equalTo("User1"))
		.body("age", equalTo(35))
		.body("accountId", equalTo(1234));
	}

	@Test
	public void testCreateUser() {

		User userObj = new User();

		userObj.setAccountId(12563);
		userObj.setAge(50);
		userObj.setId(20);
		userObj.setName("UserXYZ");

		Gson gson = new Gson();
		String userObjStr = gson.toJson(userObj);

		Header acceptHeaderJson = new Header("Accept", "application/json");
		Header contentHeaderJson = new Header("Content-Type", "application/json");

		Response resp = io.restassured.RestAssured.given()
				.contentType(ContentType.JSON)
				.header(acceptHeaderJson)
				.header(contentHeaderJson)
				.body(userObjStr)
				.expect()
				.statusCode(201)  /// ---------- validated the Code here
				.log().ifError()
				.when()
				.post("http://localhost:1234/api/users/new");

		logger.info( " resp ===== " + resp.asString());
	
		JsonPath jsonPathEvaluator = resp.jsonPath();
		
		String name = jsonPathEvaluator.get("name");
		Assert.assertEquals( "Name doesn't match", userObj.getName(), name);
		
		int id = jsonPathEvaluator.get("id");
		Assert.assertEquals( "Id doesn't match", userObj.getId(), id);
		
		int age = jsonPathEvaluator.get("age");
		Assert.assertEquals( "Age doesn't match", userObj.getAge(), age);

	}
}