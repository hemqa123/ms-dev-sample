package com.techm.ms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.techm.ms.model.User;
import com.techm.ms.resource.UserResourceImpl;

@Service("userService")
public class UserServiceImpl implements UserService{
	
	public static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
	
	private static final AtomicLong counter = new AtomicLong();
	
	private static List<User> UsersList;
	
	static {
		UsersList= populateDummyUsers();
	}

	public List<User> findAllUsers() {
		return UsersList;
	}
	
	public User findById(long id) {
		for(User user : UsersList){
			if(user.getId() == id){
				return user;
			}
		}
		return null;
	}
	
	public User findByName(String name) {
		
		logger.info( " given name " + name);
		for(User user : UsersList){
			
			logger.info( " user name " + user.getName());
			
			if(user.getName().equalsIgnoreCase(name)){
				
				logger.info( " Matches !!!!!! user name " + user.getName());
				return user;
			}
		}
		return null;
	}
	
	public void saveUser(User user) {
		
		counter.incrementAndGet();
		UsersList.add(user);
	}

	

	public boolean isUserExist(User user) {
		return findById(user.getId())!=null;
	}
	
	
	
	
	
	//User(long id, String name, int age, int accountId) {
	private static List<User> populateDummyUsers(){
		List<User> accounts = new ArrayList<User>();
		accounts.add(new User(counter.incrementAndGet(),"User1", 35, 1234 ));
		accounts.add(new User(counter.incrementAndGet(),"User2", 37, 6234 ));
		accounts.add(new User(counter.incrementAndGet(),"User3", 45, 9234 ));
		return accounts;
	}

}
